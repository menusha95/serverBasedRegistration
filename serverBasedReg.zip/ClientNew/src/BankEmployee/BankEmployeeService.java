package BankEmployee;

import com.mysql.jdbc.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import javax.jws.Oneway;
import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

@WebService(serviceName = "BankEmployeeService")
public class BankEmployeeService {
String sql;
    Connection connection;
    Statement stmt;
    
    /**
     * Web service operation
     */
    @WebMethod(operationName = "connectEmployee")
    @Oneway
    public void connect(@WebParam(name = "driver") String driver, @WebParam(name = "url") String url, @WebParam(name = "userName") String userName, @WebParam(name = "passWord") String passWord, @WebParam(name = "query") String query) {
        driver = "com.mysql.jdbc.Driver";
        url = "jdbc:mysql://localhost/employee";
        userName = "root";
        passWord = "";
        try {
            Class.forName(driver);
        } catch (ClassNotFoundException ex) {
            System.err.println("Driver not found please install the driver");
        }
        try {
            connection = (Connection) DriverManager.getConnection(url,userName,passWord);
        } catch (SQLException ex) {
            System.err.println("Not Connected to Database Please Start the Connection");
        }
        try
        {
            stmt = connection.createStatement();
            sql = query;
            stmt.executeUpdate(sql);
        }  
        catch (SQLException e){
            e.printStackTrace();
        } 
        finally{
            if (connection != null){
                try {
                    connection.close();
                } catch (SQLException ex) {
                    System.err.println("Cannot Close Connection");
                }
            }
        }
    }
}
