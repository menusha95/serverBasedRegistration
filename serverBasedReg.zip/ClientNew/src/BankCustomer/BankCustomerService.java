package BankCustomer;

import com.mysql.jdbc.Connection;
import java.sql.SQLException;
import java.sql.DriverManager;
import java.sql.Statement;
import javax.jws.Oneway;
import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

@WebService(serviceName = "BankCustomerService")
public class BankCustomerService {
    String sql;
    Connection connection;
    Statement stmt;
    
    /**
     * Web service operation
     */
    @WebMethod(operationName = "connectCustomer")
    @Oneway
    public void connect(@WebParam(name = "query") String query) throws SQLException {
        String driver = "com.mysql.jdbc.Driver";
        String url = "jdbc:mysql://localhost/customer";
        String userName = "root";
        String passWord = "";
        try {
            Class.forName(driver);
        } catch (ClassNotFoundException ex) {
            System.err.println("Driver not found please install the driver");
        }
        try {
            connection = (Connection) DriverManager.getConnection(url, userName, passWord);
        } catch (SQLException ex) {
            System.err.println("Not Connected to Database Please Start the Connection");
        }
        try
        {
            stmt = connection.createStatement();
            sql = query;
            stmt.executeUpdate(sql);
        }  
        catch (SQLException e){
            e.printStackTrace();
        } 
        finally{
            if (connection != null){
                connection.close();
            }
        }
    }
}
